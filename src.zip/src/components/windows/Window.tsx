"use client";

import React from 'react';
import { motion } from 'framer-motion';
import { useOSStore } from '@/store/window-store';
import { WindowState } from '@/types';
import { X, Minus, Square, Maximize2 } from 'lucide-react';

import Stats from '../dashboard/Stats';
import SkillConstellation from '../3d/SkillConstellation';
import ProjectExplorer from '../windows/ProjectExplorer';
import Terminal from '../windows/Terminal';

interface WindowProps {
  data: WindowState;
}

const Window: React.FC<WindowProps> = ({ data }) => {
  const { closeWindow, focusWindow, minimizeWindow, maximizeWindow, updatePosition } = useOSStore();

  const renderContent = () => {
    switch (data.id) {
      case 'stats':
        return <Stats />;
      case 'research':
        return <SkillConstellation />;
      case 'projects':
        return <ProjectExplorer />;
      case 'terminal':
        return <Terminal />;
      default:
        return (
          <div className="font-mono text-sm text-white/80">
            [SYSTEM_LOG]: Initializing {data.id} module...
            <br />
            [STATUS]: SUCCESS
            <br />
            <div className="mt-4 p-4 border border-white/10 bg-white/5 rounded">
              This is a placeholder for the {data.id} content.
            </div>
          </div>
        );
    }
  };

  const handleDragEnd = (event: any, info: any) => {
    updatePosition(data.id, data.position.x + info.offset.x, data.position.y + info.offset.y);
  };

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ 
        scale: 1, 
        opacity: 1,
        x: data.isMaximized ? 0 : data.position.x,
        y: data.isMaximized ? 0 : data.position.y,
        width: data.isMaximized ? '100%' : data.size.width,
        height: data.isMaximized ? 'calc(100% - 48px)' : data.size.height,
      }}
      drag={!data.isMaximized}
      dragMomentum={false}
      onDragEnd={handleDragEnd}
      onMouseDown={() => focusWindow(data.id)}
      style={{ zIndex: data.zIndex, position: 'absolute' }}
      className={`os-window ${data.isMaximized ? 'rounded-none' : ''}`}
    >
      <div className="os-window-header drag-handle">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-neon-blue/50" />
          <span className="text-xs font-mono text-white/70 uppercase tracking-widest">{data.title}</span>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => minimizeWindow(data.id)} className="hover:text-neon-blue transition-colors">
            <Minus size={14} />
          </button>
          <button onClick={() => maximizeWindow(data.id)} className="hover:text-neon-purple transition-colors">
            {data.isMaximized ? <Maximize2 size={14} /> : <Square size={12} />}
          </button>
          <button onClick={() => closeWindow(data.id)} className="hover:text-neon-pink transition-colors">
            <X size={14} />
          </button>
        </div>
      </div>
      <div className="os-window-content custom-scrollbar">
        {renderContent()}
      </div>
    </motion.div>
  );
};

export default Window;
