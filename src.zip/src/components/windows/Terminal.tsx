"use client";

import React, { useState, useRef, useEffect } from 'react';

const commands = {
  help: 'Available commands: help, clear, about, projects, contact, status',
  about: 'Hafsa Fathima - Senior AI/ML Engineer specializing in Deep Learning and Computer Vision.',
  status: 'System: Stable | Kernel: v0.1.0 | AI_Core: Active',
  projects: 'Type "open projects" to launch the Project Explorer.',
  contact: 'Email: hafsa@example.com | GitHub: @hafsafathima',
};

const Terminal: React.FC = () => {
  const [history, setHistory] = useState<string[]>(['Welcome to AI_Kernel v0.1.0', 'Type "help" for a list of commands.']);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.toLowerCase().trim();
    let response = `Command not found: ${cmd}. Type "help" for assistance.`;

    if (cmd === 'clear') {
      setHistory([]);
      setInput('');
      return;
    }

    if (commands[cmd as keyof typeof commands]) {
      response = commands[cmd as keyof typeof commands];
    }

    setHistory(prev => [...prev, `> ${input}`, response]);
    setInput('');
  };

  return (
    <div className="h-full font-mono text-xs md:text-sm flex flex-col bg-black/40 p-2 rounded">
      <div className="flex-1 overflow-auto custom-scrollbar mb-2 space-y-1">
        {history.map((line, i) => (
          <div key={i} className={line.startsWith('>') ? 'text-neon-blue' : 'text-white/70'}>
            {line}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <form onSubmit={handleCommand} className="flex gap-2">
        <span className="text-neon-green">root@hafsa-ai:~$</span>
        <input
          autoFocus
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent outline-none border-none text-neon-green"
          spellCheck={false}
        />
      </form>
    </div>
  );
};

export default Terminal;
