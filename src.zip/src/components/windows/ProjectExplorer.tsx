"use client";

import React, { useState } from 'react';
import { projects } from '@/lib/data';
import { Project } from '@/types';
import { ExternalLink, Github, Code, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ProjectExplorer: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <div className="flex h-full gap-6">
      {/* Project List */}
      <div className="w-1/3 border-r border-white/10 pr-6 overflow-auto custom-scrollbar">
        <div className="space-y-2">
          {projects.map((project) => (
            <button
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className={`
                w-full text-left p-3 rounded-lg transition-all duration-300
                ${selectedProject?.id === project.id 
                  ? 'bg-neon-blue/20 border border-neon-blue/50 text-neon-blue shadow-neon-blue/20' 
                  : 'hover:bg-white/5 border border-transparent text-white/60'}
              `}
            >
              <div className="text-sm font-mono truncate">{project.title}</div>
              <div className="text-[10px] opacity-50 flex gap-1 mt-1">
                {project.tags.slice(0, 2).map(tag => (
                  <span key={tag}>#{tag}</span>
                ))}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Project Detail */}
      <div className="flex-1 overflow-auto custom-scrollbar">
        <AnimatePresence mode="wait">
          {selectedProject ? (
            <motion.div
              key={selectedProject.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-2xl font-bold neon-text-blue">{selectedProject.title}</h2>
                  <div className="flex gap-2 mt-2">
                    {selectedProject.tags.map(tag => (
                      <span key={tag} className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white/40">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  {selectedProject.github && (
                    <a href={selectedProject.github} target="_blank" rel="noreferrer" className="p-2 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors">
                      <Github size={20} />
                    </a>
                  )}
                  {selectedProject.demo && (
                    <a href={selectedProject.demo} target="_blank" rel="noreferrer" className="p-2 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors">
                      <ExternalLink size={20} />
                    </a>
                  )}
                </div>
              </div>

              <div className="p-4 glass-panel rounded-xl bg-white/5">
                <p className="text-sm leading-relaxed text-white/80">{selectedProject.description}</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 text-neon-purple">
                  <Layers size={18} />
                  <span className="text-xs font-mono uppercase tracking-widest">Architecture_Explorer</span>
                </div>
                <div className="p-4 border border-neon-purple/20 bg-neon-purple/5 rounded-xl font-mono text-xs text-neon-purple/80 leading-loose">
                  {selectedProject.architecture}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 text-neon-green">
                  <Code size={18} />
                  <span className="text-xs font-mono uppercase tracking-widest">Technical_Highlights</span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 border border-white/10 bg-white/5 rounded-lg text-[10px] text-white/40">
                    Precision: 98.2%
                  </div>
                  <div className="p-3 border border-white/10 bg-white/5 rounded-lg text-[10px] text-white/40">
                    Latency: 45ms
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-white/20 font-mono space-y-4">
              <Code size={48} className="animate-pulse" />
              <div className="text-xs uppercase tracking-[0.2em]">Select_a_project_to_initialize</div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ProjectExplorer;
