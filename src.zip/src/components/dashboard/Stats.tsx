"use client";

import React, { useState, useEffect } from 'react';
import { Activity, Cpu, Database, Zap } from 'lucide-react';

const Stats: React.FC = () => {
  const [metrics, setMetrics] = useState({
    cpu: 45,
    memory: 62,
    models: 12,
    uptime: '00:00:00'
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        cpu: Math.floor(Math.random() * 20) + 30,
        memory: Math.floor(Math.random() * 10) + 55,
      }));
    }, 2000);

    const startTime = Date.now();
    const uptimeInterval = setInterval(() => {
      const diff = Date.now() - startTime;
      const hours = Math.floor(diff / 3600000).toString().padStart(2, '0');
      const mins = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
      const secs = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
      setMetrics(prev => ({ ...prev, uptime: `${hours}:${mins}:${secs}` }));
    }, 1000);

    return () => {
      clearInterval(interval);
      clearInterval(uptimeInterval);
    };
  }, []);

  return (
    <div className="space-y-6 font-mono">
      <div className="grid grid-cols-2 gap-4">
        <div className="p-3 border border-white/10 bg-white/5 rounded-lg">
          <div className="flex items-center gap-2 text-neon-blue mb-2">
            <Cpu size={16} />
            <span className="text-xs uppercase">CPU_LOAD</span>
          </div>
          <div className="text-2xl">{metrics.cpu}%</div>
          <div className="w-full bg-white/10 h-1 mt-2 rounded-full overflow-hidden">
            <div className="bg-neon-blue h-full transition-all duration-500" style={{ width: `${metrics.cpu}%` }} />
          </div>
        </div>

        <div className="p-3 border border-white/10 bg-white/5 rounded-lg">
          <div className="flex items-center gap-2 text-neon-purple mb-2">
            <Database size={16} />
            <span className="text-xs uppercase">MEM_USAGE</span>
          </div>
          <div className="text-2xl">{metrics.memory}%</div>
          <div className="w-full bg-white/10 h-1 mt-2 rounded-full overflow-hidden">
            <div className="bg-neon-purple h-full transition-all duration-500" style={{ width: `${metrics.memory}%` }} />
          </div>
        </div>
      </div>

      <div className="p-4 border border-neon-blue/20 bg-neon-blue/5 rounded-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-neon-blue">
            <Activity size={18} />
            <span className="text-sm uppercase tracking-widest">Active_Models</span>
          </div>
          <span className="text-neon-blue text-xs">ONLINE</span>
        </div>
        <div className="space-y-3">
          {[
            { name: 'GESTURE_CAR_V2', status: 'READY', load: 12 },
            { name: 'MOODIE_CORE_AI', status: 'ACTIVE', load: 45 },
            { name: 'EYE_DISEASE_DETECTOR', status: 'STANDBY', load: 0 },
          ].map((model, i) => (
            <div key={i} className="flex items-center justify-between text-xs">
              <span className="text-white/60">{model.name}</span>
              <span className={model.status === 'ACTIVE' ? 'text-neon-green' : 'text-white/40'}>{model.status}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between p-3 border border-white/10 bg-white/5 rounded-lg">
        <div className="flex items-center gap-2 text-white/40">
          <Zap size={14} />
          <span className="text-[10px] uppercase">Kernel_Uptime</span>
        </div>
        <div className="text-sm text-neon-blue">{metrics.uptime}</div>
      </div>
    </div>
  );
};

export default Stats;
