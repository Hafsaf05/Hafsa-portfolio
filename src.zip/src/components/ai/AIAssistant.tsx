"use client";

import React, { useState } from 'react';
import { Bot, Send, X, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Greeting initialized. I am the AI Mission Control assistant. How can I help you explore Hafsa\'s portfolio?' }
  ]);
  const [input, setInput] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Mock response
    setTimeout(() => {
      let response = "I'm analyzing your request... Based on Hafsa's background, she has extensive experience in Deep Learning and Computer Vision. Would you like to see her project on Pneumonia Detection?";
      if (input.toLowerCase().includes('hire')) {
        response = "Hafsa is a strong candidate for AI/ML roles due to her end-to-end engineering skills. You can find her resume in the Recruiter Quick-Access panel.";
      }
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    }, 1000);
  };

  return (
    <div className="fixed bottom-20 right-6 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="w-80 h-96 glass-panel rounded-2xl flex flex-col mb-4 overflow-hidden border-neon-blue/30 shadow-neon-blue/20 shadow-2xl"
          >
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-neon-blue/10">
              <div className="flex items-center gap-2 text-neon-blue">
                <Bot size={20} />
                <span className="text-xs font-mono font-bold uppercase tracking-widest">AI_COPILOT_V1</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/50 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Chat Body */}
            <div className="flex-1 overflow-auto p-4 space-y-4 custom-scrollbar">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`
                    max-w-[80%] p-3 rounded-xl text-xs leading-relaxed
                    ${msg.role === 'user' ? 'bg-neon-blue/20 text-neon-blue border border-neon-blue/30' : 'bg-white/5 text-white/80 border border-white/10'}
                  `}>
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-3 border-t border-white/10 bg-black/20 flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask me anything..."
                className="flex-1 bg-transparent text-xs outline-none text-white/70"
              />
              <button type="submit" className="text-neon-blue hover:scale-110 transition-transform">
                <Send size={16} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-12 h-12 rounded-full glass-panel flex items-center justify-center text-neon-blue border-neon-blue/50 shadow-neon-blue/20 shadow-lg hover:shadow-neon-blue/40 transition-shadow"
      >
        <MessageSquare size={24} />
      </motion.button>
    </div>
  );
};

export default AIAssistant;
