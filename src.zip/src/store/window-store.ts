import { create } from 'zustand';
import { WindowState, WindowType } from '@/types';

interface OSState {
  windows: WindowState[];
  activeWindowId: WindowType | null;
  openWindow: (id: WindowType) => void;
  closeWindow: (id: WindowType) => void;
  focusWindow: (id: WindowType) => void;
  minimizeWindow: (id: WindowType) => void;
  maximizeWindow: (id: WindowType) => void;
  updatePosition: (id: WindowType, x: number, y: number) => void;
}

const initialWindows: WindowState[] = [
  {
    id: 'projects',
    title: 'Project_Explorer.exe',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 10,
    position: { x: 100, y: 100 },
    size: { width: 800, height: 600 },
  },
  {
    id: 'research',
    title: 'Knowledge_Graph.sys',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 12,
    position: { x: 450, y: 100 },
    size: { width: 600, height: 500 },
  },
  {
    id: 'stats',
    title: 'System_Metrics.sys',
    isOpen: true,
    isMinimized: false,
    isMaximized: false,
    zIndex: 11,
    position: { x: 50, y: 50 },
    size: { width: 400, height: 300 },
  },
  {
    id: 'terminal',
    title: 'AI_Kernel_Terminal',
    isOpen: false,
    isMinimized: false,
    isMaximized: false,
    zIndex: 10,
    position: { x: 150, y: 150 },
    size: { width: 600, height: 400 },
  }
];

export const useOSStore = create<OSState>((set) => ({
  windows: initialWindows,
  activeWindowId: 'stats',
  openWindow: (id) => set((state) => ({
    windows: state.windows.map(w => w.id === id ? { ...w, isOpen: true, isMinimized: false } : w),
    activeWindowId: id,
  })),
  closeWindow: (id) => set((state) => ({
    windows: state.windows.map(w => w.id === id ? { ...w, isOpen: false } : w),
    activeWindowId: state.activeWindowId === id ? null : state.activeWindowId,
  })),
  focusWindow: (id) => set((state) => {
    const maxZ = Math.max(...state.windows.map(w => w.zIndex));
    return {
      windows: state.windows.map(w => w.id === id ? { ...w, zIndex: maxZ + 1 } : w),
      activeWindowId: id,
    };
  }),
  minimizeWindow: (id) => set((state) => ({
    windows: state.windows.map(w => w.id === id ? { ...w, isMinimized: true } : w),
    activeWindowId: state.activeWindowId === id ? null : state.activeWindowId,
  })),
  maximizeWindow: (id) => set((state) => ({
    windows: state.windows.map(w => w.id === id ? { ...w, isMaximized: !w.isMaximized } : w),
  })),
  updatePosition: (id, x, y) => set((state) => ({
    windows: state.windows.map(w => w.id === id ? { ...w, position: { x, y } } : w),
  })),
}));
