import { Project } from '@/types';

export const projects: Project[] = [
  {
    id: 'gesture-car',
    title: 'Gesture Controlled AI Car',
    description: 'An AI-powered vehicle controlled via hand gestures using computer vision and Arduino.',
    tags: ['Python', 'OpenCV', 'Arduino', 'TensorFlow'],
    github: 'https://github.com/hafsafathima/gesture-car',
    architecture: 'Computer Vision Pipeline -> Gesture Mapping -> Serial Communication -> Arduino Motor Control'
  },
  {
    id: 'moodie-ai',
    title: 'Moodie AI Virtual Buddy',
    description: 'A virtual companion that uses sentiment analysis to provide emotional support and conversation.',
    tags: ['Next.js', 'OpenAI', 'Tailwind', 'Zustand'],
    github: 'https://github.com/hafsafathima/moodie-ai',
    architecture: 'Next.js Frontend -> FastAPI Middleware -> LLM (GPT-4) -> Text-to-Speech'
  },
  {
    id: 'ai-debate',
    title: 'AI Debate System',
    description: 'Multi-agent system where two AIs debate on user-provided topics with logical reasoning.',
    tags: ['Python', 'LangChain', 'OpenAI', 'Streamlit'],
    github: 'https://github.com/hafsafathima/ai-debate',
    architecture: 'LangChain Orchestrator -> Agent A (Pro) -> Agent B (Con) -> Judge Agent'
  },
  {
    id: 'pneumonia-detection',
    title: 'Pneumonia Detection',
    description: 'Deep learning model for detecting pneumonia from chest X-ray images with 95% accuracy.',
    tags: ['PyTorch', 'CNN', 'Healthcare AI'],
    github: 'https://github.com/hafsafathima/pneumonia-detection',
    architecture: 'CNN (ResNet50) -> Transfer Learning -> Grad-CAM Visualization'
  },
  {
    id: 'ocr-handwriting',
    title: 'OCR Handwriting System',
    description: 'Optical Character Recognition system optimized for handwritten medical prescriptions.',
    tags: ['Python', 'Tesseract', 'Deep Learning'],
    github: 'https://github.com/hafsafathima/ocr-handwriting',
    architecture: 'Image Preprocessing -> Contour Detection -> LSTM-based OCR -> Post-correction'
  },
  {
    id: 'eye-disease',
    title: 'Eye Disease Detection',
    description: 'Early detection of diabetic retinopathy using retinal fundus images.',
    tags: ['Keras', 'CNN', 'Medical Imaging'],
    github: 'https://github.com/hafsafathima/eye-disease',
    architecture: 'InceptionV3 -> Custom Dense Layers -> Softmax Classification'
  },
  {
    id: 'car-price',
    title: 'Car Price Prediction',
    description: 'Regression model predicting used car prices based on multiple market variables.',
    tags: ['Scikit-Learn', 'Random Forest', 'EDA'],
    github: 'https://github.com/hafsafathima/car-price',
    architecture: 'Data Cleaning -> Feature Engineering -> Random Forest Regressor -> Model Deployment'
  }
];
